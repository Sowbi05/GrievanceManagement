package com.task.grievancesystem.controller;

import com.task.grievancesystem.entity.grievance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.task.grievancesystem.service.userserv;
import com.task.grievancesystem.entity.users;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import com.task.grievancesystem.repositories.userrepo;

import java.util.List;
import java.util.Optional;


@RestController
@RequestMapping("/users")
public class usercontroller {
    
    @Autowired
    private userserv usserv;

    @Autowired
    private userrepo usrepo;

    @PostMapping("/register")
    public ResponseEntity<users> registerUser(@RequestBody users u) {
        // Register the user with the directly provided users object
        users newUser = usserv.registerUser(u.getName(), u.getEmail(), u.getPass());
        return ResponseEntity.ok(newUser);
    }


    @PostMapping("/login")
    public ResponseEntity<users> loginUser(@RequestBody users loginRequest) {
        users loggedInUser = usserv.loginUser(loginRequest.getName(), loginRequest.getPass());
        return ResponseEntity.ok(loggedInUser);
    }

    @GetMapping
    public ResponseEntity<Optional<List<users>>> getAllUsers() {
        Optional<List<users>> u = usserv.getAllUsers();
        if(u.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        else {
            return ResponseEntity.ok(u);
        }
    }

    @GetMapping("/{id}")
    public Optional<users> findUserById(@PathVariable Long id) {
        return usserv.findUserById(id);
    }

}
